package Heran�a_Exercicio6;

public class Produto {

	protected String nome;
	protected Double pre�o;
	
	public boolean ehCaro()	{
		
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Double getPre�o() {
		return pre�o;
	}
	public void setPre�o(Double pre�o) {
		this.pre�o = pre�o;
	}
	
}
