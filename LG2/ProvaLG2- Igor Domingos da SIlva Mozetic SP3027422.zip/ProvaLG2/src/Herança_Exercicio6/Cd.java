package Heran�a_Exercicio6;

public class Cd extends Midia	{

	private int faixas;

	public int getFaixas() {
		return faixas;
	}

	public void setFaixas(int faixas) {
		this.faixas = faixas;
	}
	
}
