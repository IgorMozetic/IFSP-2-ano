package Heran�a_Exercicio6;

public class Midia extends Produto {

	private String artista;

	public String getArtista() {
		return artista;
	}

	public void setArtista(String artista) {
		this.artista = artista;
	}
	
}
